---
name: Other
about: Not a feature request or bug report
title: ''
labels: Question
assignees: ''

---

Please follow this Issue template to provide relevant information, such as source code repository, website URL and screenshots, which will help us investigate.
请按照此 Issue 模版提供相关信息，例如源码仓库、网站链接和屏幕截图，这将有助于我们进行调查。

## Issue Checklist <!-- 我确认我已经查看了 -->
<!-- Change [ ] to [x] to select (将 [ ] 换成 [x] 来选择) -->

- [ ] I am using NexT version 8.0 or later.
- [ ] I have already read the relevant documents of [Hexo](https://hexo.io/docs/) and [NexT](https://theme-next.js.org/docs/).
- [ ] I have already searched for current [issues](https://github.com/next-theme/hexo-theme-next/issues), which does not help me.

***

## Other Information <!-- e.g. Browser, System -->
