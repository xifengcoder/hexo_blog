'use strict';

describe('NexT', () => {
  require('./helpers');
  require('./tags');
  require('./validate');
});
